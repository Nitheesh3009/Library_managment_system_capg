package com.lms.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "category")
public class Category {
	@Id
	@SequenceGenerator(allocationSize = 1, initialValue = 2000, name = "cat_id_gen", sequenceName = "cat_id_seq")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cat_id_gen")
	private Integer id;
	private String name;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
