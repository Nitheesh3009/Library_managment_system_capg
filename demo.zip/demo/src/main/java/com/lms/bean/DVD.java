package com.lms.bean;

public class DVD extends Product {
private Integer length;//minutes
public Integer getLength() {
	return length;
}
public void setLength(Integer length) {
	this.length = length;
}
public Integer getVolume() {
	return volume;
}
public void setVolume(Integer volume) {
	this.volume = volume;
}
private Integer volume;
}
