package com.lms.bean;

public class ELibrary extends Product{
private String url;
private LibraryType type;
public String getUrl() {
	return url;
}
public void setUrl(String url) {
	this.url = url;
}
public LibraryType getType() {
	return type;
}
public void setType(LibraryType type) {
	this.type = type;
}
}

enum LibraryType
{
	EBOOK,JOURNAL
}