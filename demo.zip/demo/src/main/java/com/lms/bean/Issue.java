package com.lms.bean;

import java.sql.Date;

public class Issue {
private Integer id;
private User user;
private Date dateOfIssue;
private Date dateOfReturn;
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public User getUser() {
	return user;
}
public void setUser(User user) {
	this.user = user;
}
public Date getDateOfIssue() {
	return dateOfIssue;
}
public void setDateOfIssue(Date dateOfIssue) {
	this.dateOfIssue = dateOfIssue;
}
public Date getDateOfReturn() {
	return dateOfReturn;
}
public void setDateOfReturn(Date dateOfReturn) {
	this.dateOfReturn = dateOfReturn;
}
}
