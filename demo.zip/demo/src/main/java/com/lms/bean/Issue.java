package com.lms.bean;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "issue")
public class Issue {
	@Id
	@SequenceGenerator(allocationSize = 1, initialValue = 10000, name = "issue_id_gen", sequenceName = "issue_id_seq")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "issue_id_gen")
	private Integer id;
	@ManyToOne(fetch = FetchType.LAZY)
	private User user;
	private Date dateOfIssue;
	private Date dateOfReturn;
	@ManyToMany(fetch = FetchType.LAZY)
	private Product product;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Date getDateOfIssue() {
		return dateOfIssue;
	}

	public void setDateOfIssue(Date dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public Date getDateOfReturn() {
		return dateOfReturn;
	}

	public void setDateOfReturn(Date dateOfReturn) {
		this.dateOfReturn = dateOfReturn;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}
}
