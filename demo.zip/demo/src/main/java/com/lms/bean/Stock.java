package com.lms.bean;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "stock")
public class Stock {
	@Id
	@SequenceGenerator(allocationSize = 1, initialValue = 10000, name = "stock_id_gen", sequenceName = "stock_id_seq")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "stock_id_gen")
	private Integer id;
	private Integer copies;
	@OneToOne(fetch = FetchType.LAZY)
	private Product product;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCopies() {
		return copies;
	}

	public void setCopies(Integer copies) {
		this.copies = copies;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

}
