package com.lms.bean;

public class Stock {
private Integer id;
private Integer copies;
private Product product;
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public Integer getCopies() {
	return copies;
}
public void setCopies(Integer copies) {
	this.copies = copies;
}
public Product getProduct() {
	return product;
}
public void setProduct(Product product) {
	this.product = product;
}

}
