package com.lms.service;

public interface AdminService {

}
