package com.lms.service;

public interface UserService {

}
