package com.lms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lms.dao.ELibraryDao;
import com.lms.dao.IssueDao;
import com.lms.dao.ProductDao;
import com.lms.dao.StockDao;
import com.lms.dao.UserDao;

@Service("userService")
public class UserServiceImpl implements UserService {
	private IssueDao issueDao;
	private ProductDao productDao;
	private ELibraryDao eLibraryDao;
	private StockDao stockDao;
	private UserDao userDao;

	@Autowired
	public void setIssueDao(IssueDao issueDao) {
		this.issueDao = issueDao;
	}

	@Autowired
	public void setELibraryDao(ELibraryDao eLibraryDao) {
		this.eLibraryDao = eLibraryDao;
	}

	@Autowired
	public void setProductDao(ProductDao productDao) {
		this.productDao = productDao;
	}

	@Autowired
	public void setStockDao(StockDao stockDao) {
		this.stockDao = stockDao;
	}

	@Autowired
	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}
}
